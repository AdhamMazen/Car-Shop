// Select necessary elements
const signoutBtn = document.querySelector(".log-out");
const settingBtn = document.querySelector(".setting-btn");
const xBtn = document.querySelector(".fa-x");
const settingBox = document.querySelector(".setting-box");
const backgroundColors = document.querySelectorAll(".setting-box ul li:nth-child(4) ul li");
const cardStars = document.querySelectorAll(".card-star");

// Load and set main background color from local storage
const rootStyles = getComputedStyle(document.documentElement);
const savedColor = window.localStorage.getItem("color") || rootStyles.getPropertyValue('--mainBackgroundColor').trim();
document.documentElement.style.setProperty('--mainBackgroundColor', savedColor);

// Event listener for the sign-out button
signoutBtn.addEventListener("click", () => {
    window.close(); // Close the window on sign out
});

// Event listener to toggle the settings box visibility
settingBtn.addEventListener("click", () => {
    settingBox.style.transform = 'scale(1)'; // Show the settings box
});

xBtn.addEventListener("click", () => {
    settingBox.style.transform = 'scale(0)'; // Hide the settings box
});

// Event listener for background color selection
backgroundColors.forEach(el => {
    el.addEventListener("click", (e) => {
        const selectedColor = e.currentTarget.dataset.color;
        window.localStorage.setItem("color", selectedColor);
        document.documentElement.style.setProperty('--mainBackgroundColor', selectedColor);
    });
});

// Event listener for star rating toggle
cardStars.forEach(el => {
    el.addEventListener("click", (e) => {
        e.target.classList.toggle("active");
    });
});
